.. _plugin-index:

==================
 The Munin plugin
==================

Role
====

The munin plugin is a simple executable, which role is to gather one
set of facts about the local server.

The plugin is called with the argument "config" to get metadata, and
with no arguments to get the values.

Other documentation
===================

.. toctree::
   :maxdepth: 2

   use.rst
   writing.rst
   supersampling.rst
