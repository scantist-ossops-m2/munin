
Welcome to Munin's documentation!
=================================

Contents:

.. toctree::
   :maxdepth: 2

   installation/index.rst
   master/index.rst
   node/index.rst
   plugin/index.rst
   documentation/index.rst
   reference/index.rst
   example/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
