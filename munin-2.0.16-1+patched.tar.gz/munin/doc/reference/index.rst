.. _reference-index:

===========
 Reference
===========

This section contains man pages and other reference material

Man pages
=========

.. toctree::
   :maxdepth: 1

   munin-async.rst
   munin-asyncd.rst
   munin-cgi-graph.rst
   munin-cgi-html.rst
   munin-check.rst
   munin-cron.rst
   munin-graph.rst
   munin-html.rst
   munin-limits.rst
   munin-node.rst
   munin-run.rst
   munin-update.rst
   munin.conf.rst
   munin-node.conf.rst

Other reference material
========================

.. toctree::
   :maxdepth: 1

   directories.rst
   plugin.rst
