.. _example-index:

========
Examples
========

Examples of munin and related configuration are gathered here.

.. toctree::
   :maxdepth: 2

   webserver/apache-virtualhost.rst
   webserver/lighttpd.rst
   webserver/nginx.rst
   graph/aggregate.rst
   tips/multimaster.rst
