.. _documentation-index:

===================
 Documenting Munin
===================

This document is rather meta, it explains how to document Munin.

.. toctree::
   :maxdepth: 2

   nomenclature.rst
