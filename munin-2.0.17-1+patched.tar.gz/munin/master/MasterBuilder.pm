package MasterBuilder;

# $Id$

use base qw(Module::Build);

use lib '../common/blib/lib';

use warnings;
use strict;

1;
